﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practico_1_y_2_Vectores_U.Ficct
{
    class vectores1
    {
        private int cantidad;
        private int[] v;
        private int max=205;
        public vectores1(){
            cantidad = 0;
            v=new int [max];
        }
    public void cargar (int cantElement, int rangMin, int rangMax)
        {
            cantidad = cantElement;
            Random o = new Random();
            for (int i = 1; i <= cantidad; i++)
            {
                v[i] = o.Next(rangMin, rangMax);
            }
        }
    public string descargar()
        {
            string result = "";
            for (int i = 1; i <= cantidad; i++)
            {
                result = result + " / " + v[i];
            }
            return result;
        }
    }
}

